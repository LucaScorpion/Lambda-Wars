lambda-wars
===========

Asteroids inspired game written in Haskell
